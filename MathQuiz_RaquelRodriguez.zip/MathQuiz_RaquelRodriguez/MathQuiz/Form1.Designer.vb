﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.timeLabel = New System.Windows.Forms.Label()
        Me.plusLeftLabel = New System.Windows.Forms.Label()
        Me.minusRigthLabel = New System.Windows.Forms.Label()
        Me.plusRigthLabel = New System.Windows.Forms.Label()
        Me.minusLeftLabel = New System.Windows.Forms.Label()
        Me.multiplyLeftLabel = New System.Windows.Forms.Label()
        Me.dividedRigthLabel = New System.Windows.Forms.Label()
        Me.dividedLeftLabel = New System.Windows.Forms.Label()
        Me.multiplyRightLabel = New System.Windows.Forms.Label()
        Me.LabelMultiplicacion = New System.Windows.Forms.Label()
        Me.LabelDivision = New System.Windows.Forms.Label()
        Me.LabelSuma = New System.Windows.Forms.Label()
        Me.LabelResta = New System.Windows.Forms.Label()
        Me.StartButton = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.add = New System.Windows.Forms.NumericUpDown()
        Me.difference = New System.Windows.Forms.NumericUpDown()
        Me.product = New System.Windows.Forms.NumericUpDown()
        Me.quocient = New System.Windows.Forms.NumericUpDown()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.add, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.difference, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.product, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.quocient, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(229, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 21)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Time remaining"
        '
        'timeLabel
        '
        Me.timeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.timeLabel.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.timeLabel.Location = New System.Drawing.Point(354, 9)
        Me.timeLabel.Name = "timeLabel"
        Me.timeLabel.Size = New System.Drawing.Size(118, 25)
        Me.timeLabel.TabIndex = 2
        '
        'plusLeftLabel
        '
        Me.plusLeftLabel.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.plusLeftLabel.Location = New System.Drawing.Point(79, 54)
        Me.plusLeftLabel.Name = "plusLeftLabel"
        Me.plusLeftLabel.Size = New System.Drawing.Size(46, 40)
        Me.plusLeftLabel.TabIndex = 3
        Me.plusLeftLabel.Text = "?"
        Me.plusLeftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'minusRigthLabel
        '
        Me.minusRigthLabel.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.minusRigthLabel.Location = New System.Drawing.Point(183, 105)
        Me.minusRigthLabel.Name = "minusRigthLabel"
        Me.minusRigthLabel.Size = New System.Drawing.Size(46, 40)
        Me.minusRigthLabel.TabIndex = 4
        Me.minusRigthLabel.Text = "?"
        Me.minusRigthLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'plusRigthLabel
        '
        Me.plusRigthLabel.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.plusRigthLabel.Location = New System.Drawing.Point(183, 54)
        Me.plusRigthLabel.Name = "plusRigthLabel"
        Me.plusRigthLabel.Size = New System.Drawing.Size(46, 40)
        Me.plusRigthLabel.TabIndex = 5
        Me.plusRigthLabel.Text = "?"
        Me.plusRigthLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'minusLeftLabel
        '
        Me.minusLeftLabel.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.minusLeftLabel.Location = New System.Drawing.Point(79, 105)
        Me.minusLeftLabel.Name = "minusLeftLabel"
        Me.minusLeftLabel.Size = New System.Drawing.Size(46, 40)
        Me.minusLeftLabel.TabIndex = 6
        Me.minusLeftLabel.Text = "?"
        Me.minusLeftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'multiplyLeftLabel
        '
        Me.multiplyLeftLabel.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.multiplyLeftLabel.Location = New System.Drawing.Point(79, 154)
        Me.multiplyLeftLabel.Name = "multiplyLeftLabel"
        Me.multiplyLeftLabel.Size = New System.Drawing.Size(46, 40)
        Me.multiplyLeftLabel.TabIndex = 7
        Me.multiplyLeftLabel.Text = "?"
        Me.multiplyLeftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dividedRigthLabel
        '
        Me.dividedRigthLabel.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.dividedRigthLabel.Location = New System.Drawing.Point(183, 204)
        Me.dividedRigthLabel.Name = "dividedRigthLabel"
        Me.dividedRigthLabel.Size = New System.Drawing.Size(46, 40)
        Me.dividedRigthLabel.TabIndex = 8
        Me.dividedRigthLabel.Text = "?"
        Me.dividedRigthLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dividedLeftLabel
        '
        Me.dividedLeftLabel.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.dividedLeftLabel.Location = New System.Drawing.Point(79, 204)
        Me.dividedLeftLabel.Name = "dividedLeftLabel"
        Me.dividedLeftLabel.Size = New System.Drawing.Size(46, 40)
        Me.dividedLeftLabel.TabIndex = 9
        Me.dividedLeftLabel.Text = "?"
        Me.dividedLeftLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'multiplyRightLabel
        '
        Me.multiplyRightLabel.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.multiplyRightLabel.Location = New System.Drawing.Point(183, 154)
        Me.multiplyRightLabel.Name = "multiplyRightLabel"
        Me.multiplyRightLabel.Size = New System.Drawing.Size(46, 40)
        Me.multiplyRightLabel.TabIndex = 10
        Me.multiplyRightLabel.Text = "?"
        Me.multiplyRightLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelMultiplicacion
        '
        Me.LabelMultiplicacion.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LabelMultiplicacion.Location = New System.Drawing.Point(131, 154)
        Me.LabelMultiplicacion.Name = "LabelMultiplicacion"
        Me.LabelMultiplicacion.Size = New System.Drawing.Size(46, 40)
        Me.LabelMultiplicacion.TabIndex = 14
        Me.LabelMultiplicacion.Text = "x"
        Me.LabelMultiplicacion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelDivision
        '
        Me.LabelDivision.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LabelDivision.Location = New System.Drawing.Point(131, 204)
        Me.LabelDivision.Name = "LabelDivision"
        Me.LabelDivision.Size = New System.Drawing.Size(46, 40)
        Me.LabelDivision.TabIndex = 13
        Me.LabelDivision.Text = "÷"
        Me.LabelDivision.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelSuma
        '
        Me.LabelSuma.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LabelSuma.Location = New System.Drawing.Point(131, 54)
        Me.LabelSuma.Name = "LabelSuma"
        Me.LabelSuma.Size = New System.Drawing.Size(46, 40)
        Me.LabelSuma.TabIndex = 12
        Me.LabelSuma.Text = "+"
        Me.LabelSuma.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelResta
        '
        Me.LabelResta.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LabelResta.Location = New System.Drawing.Point(131, 105)
        Me.LabelResta.Name = "LabelResta"
        Me.LabelResta.Size = New System.Drawing.Size(46, 40)
        Me.LabelResta.TabIndex = 11
        Me.LabelResta.Text = "-"
        Me.LabelResta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StartButton
        '
        Me.StartButton.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.StartButton.Location = New System.Drawing.Point(171, 269)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(119, 36)
        Me.StartButton.TabIndex = 1
        Me.StartButton.Text = "Start the Quiz"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(235, 154)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(46, 40)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "="
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(235, 204)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(46, 40)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "="
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(235, 54)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(46, 40)
        Me.Label15.TabIndex = 17
        Me.Label15.Text = "="
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label16.Location = New System.Drawing.Point(235, 105)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(46, 40)
        Me.Label16.TabIndex = 16
        Me.Label16.Text = "="
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'add
        '
        Me.add.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.add.Location = New System.Drawing.Point(287, 63)
        Me.add.Name = "add"
        Me.add.Size = New System.Drawing.Size(120, 29)
        Me.add.TabIndex = 20
        '
        'difference
        '
        Me.difference.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.difference.Location = New System.Drawing.Point(287, 114)
        Me.difference.Name = "difference"
        Me.difference.Size = New System.Drawing.Size(120, 29)
        Me.difference.TabIndex = 21
        '
        'product
        '
        Me.product.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.product.Location = New System.Drawing.Point(287, 165)
        Me.product.Name = "product"
        Me.product.Size = New System.Drawing.Size(120, 29)
        Me.product.TabIndex = 22
        '
        'quocient
        '
        Me.quocient.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.quocient.Location = New System.Drawing.Point(287, 213)
        Me.quocient.Name = "quocient"
        Me.quocient.Size = New System.Drawing.Size(120, 29)
        Me.quocient.TabIndex = 23
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(484, 317)
        Me.Controls.Add(Me.quocient)
        Me.Controls.Add(Me.product)
        Me.Controls.Add(Me.difference)
        Me.Controls.Add(Me.add)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.LabelMultiplicacion)
        Me.Controls.Add(Me.LabelDivision)
        Me.Controls.Add(Me.LabelSuma)
        Me.Controls.Add(Me.LabelResta)
        Me.Controls.Add(Me.multiplyRightLabel)
        Me.Controls.Add(Me.dividedLeftLabel)
        Me.Controls.Add(Me.dividedRigthLabel)
        Me.Controls.Add(Me.multiplyLeftLabel)
        Me.Controls.Add(Me.minusLeftLabel)
        Me.Controls.Add(Me.plusRigthLabel)
        Me.Controls.Add(Me.minusRigthLabel)
        Me.Controls.Add(Me.plusLeftLabel)
        Me.Controls.Add(Me.timeLabel)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Math Quiz by Raquel"
        CType(Me.add, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.difference, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.product, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.quocient, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents timeLabel As Label
    Friend WithEvents plusLeftLabel As Label
    Friend WithEvents minusRigthLabel As Label
    Friend WithEvents plusRigthLabel As Label
    Friend WithEvents minusLeftLabel As Label
    Friend WithEvents multiplyLeftLabel As Label
    Friend WithEvents dividedRigthLabel As Label
    Friend WithEvents dividedLeftLabel As Label
    Friend WithEvents multiplyRightLabel As Label
    Friend WithEvents LabelMultiplicacion As Label
    Friend WithEvents LabelDivision As Label
    Friend WithEvents LabelSuma As Label
    Friend WithEvents LabelResta As Label
    Friend WithEvents StartButton As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents add As NumericUpDown
    Friend WithEvents difference As NumericUpDown
    Friend WithEvents product As NumericUpDown
    Friend WithEvents quocient As NumericUpDown
    Friend WithEvents Timer1 As Timer
End Class
