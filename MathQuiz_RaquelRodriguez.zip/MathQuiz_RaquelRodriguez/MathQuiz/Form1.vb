﻿Public Class Form1
    ' Create a Random object to generate random numbers.
    Dim randomizer As New Random

    ' These Integers will store the numbers for the addition problem.
    Dim addend1 As Integer
    Dim addend2 As Integer

    ' These Integers will store the numbers for the subtraction problem.
    Dim minuend As Integer
    Dim subtrahend As Integer

    ' These Integers will store the numbers for the multiplication problem.
    Dim multiplicand As Integer
    Dim multiplier As Integer

    ' These Integers will store the numbers for the division problem.
    Dim dividend As Integer
    Dim divisor As Integer

    ' This Integer will keep track of the time left.
    Dim timeLeft As Integer

    Public Sub StartTheQuiz()
        ' Fill in the addition problem.
        addend1 = randomizer.Next(51)
        addend2 = randomizer.Next(51)
        plusLeftLabel.Text = addend1.ToString
        plusRigthLabel.Text = addend2.ToString
        add.Value = 0

        ' Fill in the subtraction problem.
        minuend = randomizer.Next(1, 101)
        subtrahend = randomizer.Next(1, minuend)
        minusLeftLabel.Text = minuend.ToString
        minusRigthLabel.Text = subtrahend.ToString
        difference.Value = 0

        ' Fill in the multiplication problem.
        multiplicand = randomizer.Next(2, 11)
        multiplier = randomizer.Next(2, 11)
        multiplyLeftLabel.Text = multiplicand.ToString
        multiplyRightLabel.Text = multiplier.ToString
        product.Value = 0

        ' Fill in the division problem.
        divisor = randomizer.Next(2, 11)
        Dim temporaryQuotient As Integer = randomizer.Next(2, 11)
        dividend = divisor * temporaryQuotient
        dividedLeftLabel.Text = dividend.ToString
        dividedRigthLabel.Text = divisor.ToString
        quocient.Value = 0

        ' Start the timer.
        timeLeft = 30
        timeLabel.Text = "30 seconds"
        Timer1.Start()
    End Sub

    Private Sub StartButton_Click(sender As Object, e As EventArgs) Handles StartButton.Click
        StartButton.Enabled = False
        StartTheQuiz()
    End Sub
    Private Sub Timer1_Tick() Handles Timer1.Tick
        If CheckTheAnswer() Then
            ' If the user got the answer right, stop the timer
            ' and show a MessageBox.
            Timer1.Stop()
            MessageBox.Show("You got all of the answers right!", "Congratulations!")
            StartButton.Enabled = True
        ElseIf timeLeft > 0 Then
            ' Decrese the time left by one second and display
            ' the new time left by updating the Time Left Label.
            timeLeft = timeLeft - 1
            timeLabel.Text = timeLeft & " seconds "
        Else
            ' If the user ran out of time, stop the timer, show
            ' a MessageBox, and fill in the answers.
            Timer1.Stop()
            timeLabel.Text = " Time's up! "
            MessageBox.Show(" You didn't finish in time ", " Sorry ")
            add.Value = addend1 + addend2
            difference.Value = minuend - subtrahend
            product.Value = multiplicand * multiplier
            quocient.Value = dividend / divisor
            StartButton.Enabled = True
        End If

        ' When there are less than 5 sewconds left, the color of the timeLabel changes to red.
        If timeLeft <= 5 Then
            timeLabel.BackColor = Color.Red
        End If
    End Sub

    ''' <summary>
    ''' Checks the answer to see if the user got everyting right.
    ''' </summary>
    ''' <returns> True if the answer is correct, false otherwise. </returns>
    Public Function CheckTheAnswer() As Boolean
        If ((addend1 + addend2 = add.Value) AndAlso (minuend - subtrahend = difference.Value) AndAlso (multiplicand * multiplier = product.Value) AndAlso (dividend / divisor = quocient.Value)) Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub Answer_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles add.Enter, add.Enter, product.Enter, difference.Enter, quocient.Enter
        ' Select the whole answer in the NumericUpDown control.
        Dim AnswerBox As NumericUpDown = TryCast(sender, NumericUpDown)

        If AnswerBox IsNot Nothing Then
            Dim lengthofAnswer As Integer = AnswerBox.Value.ToString().Length
            AnswerBox.Select(0, lengthofAnswer)
        End If
    End Sub
End Class