﻿Public Class Form1
    ' Variable to hold operands
    Private dblValue1 As Double
    Private dblValue2 As Double
    ' Variable that hold temporary values
    Private dblTemp As Double
    ' Variable to hold Operator
    Private strCalculate As String
    ' True if "." is used, otherwise false
    Private blnDecimalPoint As Boolean
    Private blnInputStatus As Boolean

    ' Method that handles every button that we have created and inside of it,
    ' it tracks what button is clicked
    Private Sub ButtonClickMethod(sender As Object, e As EventArgs) Handles BotonNum9.Click, BotonNum8.Click, BotonNum7.Click, BotonNum6.Click, BotonNum5.Click, BotonNum4.Click, BotonNum3.Click, BotonNum2.Click, BotonNum1.Click, BotonNum0.Click, BotonSumar.Click, BotonRestar.Click, BotonMultiplicar.Click, BotonDividir.Click, BotonDecimal.Click, BotonIgual.Click, BotonPorcentaje.Click, BotonInversa.Click, Botonx2.Click, Botonx3.Click, Botonxy.Click, BotonN.Click, BotonSigno.Click

        ' To get the button that is clicked, we use the sender object
        Dim button As Button = CType(sender, Button)

        If button.Name = "BotonNum9" Then
            TextBox.Text = TextBox.Text + "9"
        End If

        If button.Name = "BotonNum8" Then
            TextBox.Text = TextBox.Text + "8"
        End If

        If button.Name = "BotonNum7" Then
            TextBox.Text = TextBox.Text + "7"
        End If

        If button.Name = "BotonNum6" Then
            TextBox.Text = TextBox.Text + "6"
        End If

        If button.Name = "BotonNum5" Then
            TextBox.Text = TextBox.Text + "5"
        End If

        If button.Name = "BotonNum4" Then
            TextBox.Text = TextBox.Text + "4"
        End If

        If button.Name = "BotonNum3" Then
            TextBox.Text = TextBox.Text + "3"
        End If

        If button.Name = "BotonNum2" Then
            TextBox.Text = TextBox.Text + "2"
        End If

        If button.Name = "BotonNum1" Then
            TextBox.Text = TextBox.Text + "1"
        End If

        If button.Name = "BotonNum0" Then
            TextBox.Text = TextBox.Text + "0"
        End If

        If button.Name = "BotonSumar" Then
            TextBox.Text = TextBox.Text + "+"
        End If

        If button.Name = "BotonRestar" Then
            TextBox.Text = TextBox.Text + "-"
        End If

        If button.Name = "BotonMultiplicar" Then
            TextBox.Text = TextBox.Text + "*"
        End If

        If button.Name = "BotonDividir" Then
            TextBox.Text = TextBox.Text + "/"
        End If

        If button.Name = "BotonDecimal" Then
            TextBox.Text = TextBox.Text + "."
        End If

        If button.Name = "BotonPorcentaje" Then
            Dim a As Double
            a = Convert.ToDouble(TextBox.Text) / Convert.ToDouble(100)
            TextBox.Text = System.Convert.ToString(a)
        End If

        If button.Name = "BotonInversa" Then
            Dim a As Double
            a = Convert.ToDouble(1.0 / Convert.ToDouble(TextBox.Text))
            TextBox.Text = System.Convert.ToString(a)
        End If

        ' Finds the result of the operation we have typed
        If button.Name = "BotonIgual" Then
            ' Gets all the string that is inside the TextBox
            Dim ecuacion As String = TextBox.Text
            Dim resultado = New DataTable().Compute(ecuacion, Nothing)
            ' Sets the result to the TextBox
            TextBox.Text = resultado
        End If

        If button.Name = "BotonSigno" Then
            If TextBox.Text.Length <> 0 Then
                dblTemp = CType(TextBox.Text, Double)
                dblTemp *= -1
                TextBox.Text = CType(dblTemp, String)
            End If
        End If

        If button.Name = "Botonx2" Then
            Dim a As Double
            a = Convert.ToDouble(TextBox.Text) * Convert.ToDouble(TextBox.Text)
            TextBox.Text = System.Convert.ToString(a)
        End If

        If button.Name = "Botonx3" Then
            Dim a As Double
            a = Convert.ToDouble(TextBox.Text) * Convert.ToDouble(TextBox.Text) * Convert.ToDouble(TextBox.Text)
            TextBox.Text = System.Convert.ToString(a)
        End If

        If button.Name = "Botonxy" Then
            Dim base As Double
            Dim exponente As Double
            TextBox.Text = base ^ exponente
        End If

        If button.Name = "BotonN" Then
            Dim factorial As Integer = 1
            Dim b As Integer
            For b = Val(TextBox.Text) To 1 Step -1
                factorial *= b
            Next
            TextBox.Text = factorial
        End If
    End Sub

    ' If this button is clicked, the TextBox is cleared
    Private Sub BotonClearAll_Click(sender As Object, e As EventArgs) Handles BotonClearAll.Click
        TextBox.Text = ""
        dblValue1 = 0
        dblValue2 = 0
        strCalculate = String.Empty
        blnDecimalPoint = False
    End Sub

    ' If this button is clicked, the entire screen and TextBox is cleared
    Private Sub BotonClearEntry_Click(sender As Object, e As EventArgs) Handles BotonClearEntry.Click
        TextBox.Text = ""
        blnDecimalPoint = False
    End Sub

    ' If this button is clicked, ONLY the last digit is deleted
    Private Sub BotonBorrarUltDigito_Click(sender As Object, e As EventArgs) Handles BotonBorrarUltDigito.Click
        ' If we have no characters in textbox then it should not execute the code
        If Len(TextBox.Text) = 0 Then Exit Sub
        ' Now remove the last character from the textbox
        TextBox.Text = Mid(TextBox.Text, 1, Len(TextBox.Text) - 1)
    End Sub

    ' If scientific button in the menu is clicked the width of the calculator and
    ' the width of the textbox is modify to display the scientific calculator buttons
    Private Sub CientíficaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CientíficaToolStripMenuItem.Click
        Me.Width = 522
        TextBox.Width = 409
        Me.Text = "Scientific Calculator"
    End Sub

    ' If standard button in the menu is clicked the width of the calculator is restarted as the main one
    ' and the scientific one is hidden
    Private Sub EstándarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EstándarToolStripMenuItem.Click
        Me.Width = 358
        TextBox.Width = 249
        Me.Text = "Standard Calculator"
    End Sub

    ' It shows the second Form ''About...''
    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        About.Show()
    End Sub
End Class

