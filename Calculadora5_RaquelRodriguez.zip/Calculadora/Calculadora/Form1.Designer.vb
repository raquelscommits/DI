﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TextBox = New System.Windows.Forms.TextBox()
        Me.BotonNum7 = New System.Windows.Forms.Button()
        Me.BotonNum8 = New System.Windows.Forms.Button()
        Me.BotonNum9 = New System.Windows.Forms.Button()
        Me.BotonNum6 = New System.Windows.Forms.Button()
        Me.BotonNum5 = New System.Windows.Forms.Button()
        Me.BotonNum4 = New System.Windows.Forms.Button()
        Me.BotonMultiplicar = New System.Windows.Forms.Button()
        Me.BotonDividir = New System.Windows.Forms.Button()
        Me.BotonClearAll = New System.Windows.Forms.Button()
        Me.BotonNum1 = New System.Windows.Forms.Button()
        Me.BotonNum2 = New System.Windows.Forms.Button()
        Me.BotonNum3 = New System.Windows.Forms.Button()
        Me.BotonRestar = New System.Windows.Forms.Button()
        Me.BotonIgual = New System.Windows.Forms.Button()
        Me.BotonNum0 = New System.Windows.Forms.Button()
        Me.BotonDecimal = New System.Windows.Forms.Button()
        Me.BotonSumar = New System.Windows.Forms.Button()
        Me.BotonClearEntry = New System.Windows.Forms.Button()
        Me.BotonPorcentaje = New System.Windows.Forms.Button()
        Me.BotonInversa = New System.Windows.Forms.Button()
        Me.BotonBorrarUltDigito = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.VerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EstándarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CientíficaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Botonx2 = New System.Windows.Forms.Button()
        Me.BotonN = New System.Windows.Forms.Button()
        Me.Botonx3 = New System.Windows.Forms.Button()
        Me.Botonxy = New System.Windows.Forms.Button()
        Me.BotonSigno = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox
        '
        Me.TextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox.Location = New System.Drawing.Point(47, 55)
        Me.TextBox.Multiline = True
        Me.TextBox.Name = "TextBox"
        Me.TextBox.Size = New System.Drawing.Size(249, 43)
        Me.TextBox.TabIndex = 0
        Me.TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'BotonNum7
        '
        Me.BotonNum7.BackColor = System.Drawing.Color.Silver
        Me.BotonNum7.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum7.Location = New System.Drawing.Point(47, 170)
        Me.BotonNum7.Name = "BotonNum7"
        Me.BotonNum7.Size = New System.Drawing.Size(45, 37)
        Me.BotonNum7.TabIndex = 1
        Me.BotonNum7.Text = "7"
        Me.BotonNum7.UseVisualStyleBackColor = False
        '
        'BotonNum8
        '
        Me.BotonNum8.BackColor = System.Drawing.Color.Silver
        Me.BotonNum8.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum8.Location = New System.Drawing.Point(98, 170)
        Me.BotonNum8.Name = "BotonNum8"
        Me.BotonNum8.Size = New System.Drawing.Size(45, 37)
        Me.BotonNum8.TabIndex = 2
        Me.BotonNum8.Text = "8"
        Me.BotonNum8.UseVisualStyleBackColor = False
        '
        'BotonNum9
        '
        Me.BotonNum9.BackColor = System.Drawing.Color.Silver
        Me.BotonNum9.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum9.Location = New System.Drawing.Point(149, 170)
        Me.BotonNum9.Name = "BotonNum9"
        Me.BotonNum9.Size = New System.Drawing.Size(45, 37)
        Me.BotonNum9.TabIndex = 3
        Me.BotonNum9.Text = "9"
        Me.BotonNum9.UseVisualStyleBackColor = False
        '
        'BotonNum6
        '
        Me.BotonNum6.BackColor = System.Drawing.Color.Silver
        Me.BotonNum6.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum6.Location = New System.Drawing.Point(149, 213)
        Me.BotonNum6.Name = "BotonNum6"
        Me.BotonNum6.Size = New System.Drawing.Size(45, 37)
        Me.BotonNum6.TabIndex = 6
        Me.BotonNum6.Text = "6"
        Me.BotonNum6.UseVisualStyleBackColor = False
        '
        'BotonNum5
        '
        Me.BotonNum5.BackColor = System.Drawing.Color.Silver
        Me.BotonNum5.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum5.Location = New System.Drawing.Point(98, 213)
        Me.BotonNum5.Name = "BotonNum5"
        Me.BotonNum5.Size = New System.Drawing.Size(45, 37)
        Me.BotonNum5.TabIndex = 5
        Me.BotonNum5.Text = "5"
        Me.BotonNum5.UseVisualStyleBackColor = False
        '
        'BotonNum4
        '
        Me.BotonNum4.BackColor = System.Drawing.Color.Silver
        Me.BotonNum4.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum4.Location = New System.Drawing.Point(47, 213)
        Me.BotonNum4.Name = "BotonNum4"
        Me.BotonNum4.Size = New System.Drawing.Size(45, 37)
        Me.BotonNum4.TabIndex = 4
        Me.BotonNum4.Text = "4"
        Me.BotonNum4.UseVisualStyleBackColor = False
        '
        'BotonMultiplicar
        '
        Me.BotonMultiplicar.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonMultiplicar.Location = New System.Drawing.Point(200, 213)
        Me.BotonMultiplicar.Name = "BotonMultiplicar"
        Me.BotonMultiplicar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BotonMultiplicar.Size = New System.Drawing.Size(45, 37)
        Me.BotonMultiplicar.TabIndex = 7
        Me.BotonMultiplicar.Text = "*"
        Me.BotonMultiplicar.UseVisualStyleBackColor = True
        '
        'BotonDividir
        '
        Me.BotonDividir.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonDividir.Location = New System.Drawing.Point(200, 170)
        Me.BotonDividir.Name = "BotonDividir"
        Me.BotonDividir.Size = New System.Drawing.Size(45, 37)
        Me.BotonDividir.TabIndex = 8
        Me.BotonDividir.Text = "/"
        Me.BotonDividir.UseVisualStyleBackColor = True
        '
        'BotonClearAll
        '
        Me.BotonClearAll.BackColor = System.Drawing.Color.IndianRed
        Me.BotonClearAll.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonClearAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonClearAll.Location = New System.Drawing.Point(251, 170)
        Me.BotonClearAll.Name = "BotonClearAll"
        Me.BotonClearAll.Size = New System.Drawing.Size(45, 37)
        Me.BotonClearAll.TabIndex = 9
        Me.BotonClearAll.Text = "C"
        Me.BotonClearAll.UseVisualStyleBackColor = False
        '
        'BotonNum1
        '
        Me.BotonNum1.BackColor = System.Drawing.Color.Silver
        Me.BotonNum1.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum1.Location = New System.Drawing.Point(47, 256)
        Me.BotonNum1.Name = "BotonNum1"
        Me.BotonNum1.Size = New System.Drawing.Size(45, 37)
        Me.BotonNum1.TabIndex = 11
        Me.BotonNum1.Text = "1"
        Me.BotonNum1.UseVisualStyleBackColor = False
        '
        'BotonNum2
        '
        Me.BotonNum2.BackColor = System.Drawing.Color.Silver
        Me.BotonNum2.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum2.Location = New System.Drawing.Point(98, 256)
        Me.BotonNum2.Name = "BotonNum2"
        Me.BotonNum2.Size = New System.Drawing.Size(45, 37)
        Me.BotonNum2.TabIndex = 12
        Me.BotonNum2.Text = "2"
        Me.BotonNum2.UseVisualStyleBackColor = False
        '
        'BotonNum3
        '
        Me.BotonNum3.BackColor = System.Drawing.Color.Silver
        Me.BotonNum3.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum3.Location = New System.Drawing.Point(149, 256)
        Me.BotonNum3.Name = "BotonNum3"
        Me.BotonNum3.Size = New System.Drawing.Size(45, 37)
        Me.BotonNum3.TabIndex = 13
        Me.BotonNum3.Text = "3"
        Me.BotonNum3.UseVisualStyleBackColor = False
        '
        'BotonRestar
        '
        Me.BotonRestar.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonRestar.Location = New System.Drawing.Point(200, 256)
        Me.BotonRestar.Name = "BotonRestar"
        Me.BotonRestar.Size = New System.Drawing.Size(45, 37)
        Me.BotonRestar.TabIndex = 14
        Me.BotonRestar.Text = "-"
        Me.BotonRestar.UseVisualStyleBackColor = True
        '
        'BotonIgual
        '
        Me.BotonIgual.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonIgual.Location = New System.Drawing.Point(251, 256)
        Me.BotonIgual.Name = "BotonIgual"
        Me.BotonIgual.Size = New System.Drawing.Size(45, 80)
        Me.BotonIgual.TabIndex = 15
        Me.BotonIgual.Text = "="
        Me.BotonIgual.UseVisualStyleBackColor = True
        '
        'BotonNum0
        '
        Me.BotonNum0.BackColor = System.Drawing.Color.Silver
        Me.BotonNum0.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonNum0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BotonNum0.Location = New System.Drawing.Point(47, 299)
        Me.BotonNum0.Name = "BotonNum0"
        Me.BotonNum0.Size = New System.Drawing.Size(96, 37)
        Me.BotonNum0.TabIndex = 16
        Me.BotonNum0.Text = "0"
        Me.BotonNum0.UseVisualStyleBackColor = False
        '
        'BotonDecimal
        '
        Me.BotonDecimal.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonDecimal.Location = New System.Drawing.Point(149, 299)
        Me.BotonDecimal.Name = "BotonDecimal"
        Me.BotonDecimal.Size = New System.Drawing.Size(45, 37)
        Me.BotonDecimal.TabIndex = 17
        Me.BotonDecimal.Text = "."
        Me.BotonDecimal.UseVisualStyleBackColor = True
        '
        'BotonSumar
        '
        Me.BotonSumar.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonSumar.Location = New System.Drawing.Point(200, 299)
        Me.BotonSumar.Name = "BotonSumar"
        Me.BotonSumar.Size = New System.Drawing.Size(45, 37)
        Me.BotonSumar.TabIndex = 18
        Me.BotonSumar.Text = "+"
        Me.BotonSumar.UseVisualStyleBackColor = True
        '
        'BotonClearEntry
        '
        Me.BotonClearEntry.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonClearEntry.Location = New System.Drawing.Point(251, 213)
        Me.BotonClearEntry.Name = "BotonClearEntry"
        Me.BotonClearEntry.Size = New System.Drawing.Size(45, 37)
        Me.BotonClearEntry.TabIndex = 19
        Me.BotonClearEntry.Text = "CE"
        Me.BotonClearEntry.UseVisualStyleBackColor = True
        '
        'BotonPorcentaje
        '
        Me.BotonPorcentaje.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonPorcentaje.Location = New System.Drawing.Point(48, 124)
        Me.BotonPorcentaje.Name = "BotonPorcentaje"
        Me.BotonPorcentaje.Size = New System.Drawing.Size(45, 40)
        Me.BotonPorcentaje.TabIndex = 20
        Me.BotonPorcentaje.Text = "%"
        Me.BotonPorcentaje.UseVisualStyleBackColor = True
        '
        'BotonInversa
        '
        Me.BotonInversa.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonInversa.Location = New System.Drawing.Point(99, 124)
        Me.BotonInversa.Name = "BotonInversa"
        Me.BotonInversa.Size = New System.Drawing.Size(44, 40)
        Me.BotonInversa.TabIndex = 21
        Me.BotonInversa.Text = "1/x"
        Me.BotonInversa.UseVisualStyleBackColor = True
        '
        'BotonBorrarUltDigito
        '
        Me.BotonBorrarUltDigito.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonBorrarUltDigito.Location = New System.Drawing.Point(200, 124)
        Me.BotonBorrarUltDigito.Name = "BotonBorrarUltDigito"
        Me.BotonBorrarUltDigito.Size = New System.Drawing.Size(96, 40)
        Me.BotonBorrarUltDigito.TabIndex = 22
        Me.BotonBorrarUltDigito.Text = "⌫"
        Me.BotonBorrarUltDigito.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VerToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(340, 24)
        Me.MenuStrip1.TabIndex = 23
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'VerToolStripMenuItem
        '
        Me.VerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EstándarToolStripMenuItem, Me.CientíficaToolStripMenuItem})
        Me.VerToolStripMenuItem.Name = "VerToolStripMenuItem"
        Me.VerToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.VerToolStripMenuItem.Text = "View"
        '
        'EstándarToolStripMenuItem
        '
        Me.EstándarToolStripMenuItem.Name = "EstándarToolStripMenuItem"
        Me.EstándarToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.EstándarToolStripMenuItem.Text = "Standard"
        '
        'CientíficaToolStripMenuItem
        '
        Me.CientíficaToolStripMenuItem.Name = "CientíficaToolStripMenuItem"
        Me.CientíficaToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.CientíficaToolStripMenuItem.Text = "Scientific"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.AboutToolStripMenuItem.Text = "About..."
        '
        'Botonx2
        '
        Me.Botonx2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Botonx2.Location = New System.Drawing.Point(343, 128)
        Me.Botonx2.Name = "Botonx2"
        Me.Botonx2.Size = New System.Drawing.Size(53, 37)
        Me.Botonx2.TabIndex = 27
        Me.Botonx2.Text = "x^2"
        Me.Botonx2.UseVisualStyleBackColor = True
        '
        'BotonN
        '
        Me.BotonN.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonN.Location = New System.Drawing.Point(402, 171)
        Me.BotonN.Name = "BotonN"
        Me.BotonN.Size = New System.Drawing.Size(54, 37)
        Me.BotonN.TabIndex = 26
        Me.BotonN.Text = "n!"
        Me.BotonN.UseVisualStyleBackColor = True
        '
        'Botonx3
        '
        Me.Botonx3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Botonx3.Location = New System.Drawing.Point(402, 128)
        Me.Botonx3.Name = "Botonx3"
        Me.Botonx3.Size = New System.Drawing.Size(54, 37)
        Me.Botonx3.TabIndex = 25
        Me.Botonx3.Text = "x^3"
        Me.Botonx3.UseVisualStyleBackColor = True
        '
        'Botonxy
        '
        Me.Botonxy.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Botonxy.Location = New System.Drawing.Point(342, 171)
        Me.Botonxy.Name = "Botonxy"
        Me.Botonxy.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Botonxy.Size = New System.Drawing.Size(54, 37)
        Me.Botonxy.TabIndex = 24
        Me.Botonxy.Text = "x^y"
        Me.Botonxy.UseVisualStyleBackColor = True
        '
        'BotonSigno
        '
        Me.BotonSigno.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonSigno.Location = New System.Drawing.Point(149, 125)
        Me.BotonSigno.Name = "BotonSigno"
        Me.BotonSigno.Size = New System.Drawing.Size(44, 40)
        Me.BotonSigno.TabIndex = 28
        Me.BotonSigno.Text = "+/-"
        Me.BotonSigno.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(342, 231)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(114, 105)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 29
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(340, 367)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.BotonSigno)
        Me.Controls.Add(Me.Botonx2)
        Me.Controls.Add(Me.BotonN)
        Me.Controls.Add(Me.Botonx3)
        Me.Controls.Add(Me.Botonxy)
        Me.Controls.Add(Me.BotonBorrarUltDigito)
        Me.Controls.Add(Me.BotonInversa)
        Me.Controls.Add(Me.BotonPorcentaje)
        Me.Controls.Add(Me.BotonClearEntry)
        Me.Controls.Add(Me.BotonSumar)
        Me.Controls.Add(Me.BotonDecimal)
        Me.Controls.Add(Me.BotonNum0)
        Me.Controls.Add(Me.BotonIgual)
        Me.Controls.Add(Me.BotonRestar)
        Me.Controls.Add(Me.BotonNum3)
        Me.Controls.Add(Me.BotonNum2)
        Me.Controls.Add(Me.BotonNum1)
        Me.Controls.Add(Me.BotonClearAll)
        Me.Controls.Add(Me.BotonDividir)
        Me.Controls.Add(Me.BotonMultiplicar)
        Me.Controls.Add(Me.BotonNum6)
        Me.Controls.Add(Me.BotonNum5)
        Me.Controls.Add(Me.BotonNum4)
        Me.Controls.Add(Me.BotonNum9)
        Me.Controls.Add(Me.BotonNum8)
        Me.Controls.Add(Me.BotonNum7)
        Me.Controls.Add(Me.TextBox)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Raquel's Calculator"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox As TextBox
    Friend WithEvents BotonNum7 As Button
    Friend WithEvents BotonNum8 As Button
    Friend WithEvents BotonNum9 As Button
    Friend WithEvents BotonNum6 As Button
    Friend WithEvents BotonNum5 As Button
    Friend WithEvents BotonNum4 As Button
    Friend WithEvents BotonMultiplicar As Button
    Friend WithEvents BotonDividir As Button
    Friend WithEvents BotonClearAll As Button
    Friend WithEvents BotonNum1 As Button
    Friend WithEvents BotonNum2 As Button
    Friend WithEvents BotonNum3 As Button
    Friend WithEvents BotonRestar As Button
    Friend WithEvents BotonIgual As Button
    Friend WithEvents BotonNum0 As Button
    Friend WithEvents BotonDecimal As Button
    Friend WithEvents BotonSumar As Button
    Friend WithEvents BotonClearEntry As Button
    Friend WithEvents BotonPorcentaje As Button
    Friend WithEvents BotonInversa As Button
    Friend WithEvents BotonBorrarUltDigito As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents VerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EstándarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CientíficaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Botonx2 As Button
    Friend WithEvents BotonN As Button
    Friend WithEvents Botonx3 As Button
    Friend WithEvents Botonxy As Button
    Friend WithEvents BotonSigno As Button
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
End Class
